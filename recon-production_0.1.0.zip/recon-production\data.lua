require("prototypes.combined.area-mining-drill")
require("prototypes.combined.industrial-furnace")